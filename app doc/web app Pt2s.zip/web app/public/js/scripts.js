
//pice combo box
    const serviceSelect = document.getElementById('service-select');
    const serviceSummary = document.getElementById('service-summary');
    const priceSummary = document.getElementById('price-summary');
    const totalPrice = document.getElementById('total-price');

    serviceSelect.addEventListener('change', function () {
        const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
        const price = selectedOption.getAttribute('data-price');
        
        // Update the service summary
        serviceSummary.textContent = selectedOption.value;
        priceSummary.textContent = `R ${price},00`;

        // Update the total price (assuming shipping stays constant)
        const shippingCost = 150.76;
        totalPrice.textContent = `R ${(parseFloat(price) + shippingCost).toFixed(2)}`;
    });

    //!-- JavaScript for form submission //
  
        const form = document.getElementById('contact-form');
        const messageSentDiv = document.getElementById('message-sent');

        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent form from submitting in the traditional way
            
            // Show the "Message Sent" notification
            messageSentDiv.style.display = 'block';
            
            // Optionally, reset the form fields
            form.reset();
        });